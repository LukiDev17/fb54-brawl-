from Classes.ByteStream import ByteStream
from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
from Classes.Files.Classes.Cards import Cards
from Classes.Files.Classes.Characters import Characters
import json
import random


class LogicClaimTailRewardCommand(LogicCommand):
    
    def __init__(self, commandData):
        super().__init__(commandData)

    def decode(self, calling_instance):
        fields = {}
        LogicCommand.decode(calling_instance, fields, False)
        fields["Unk1"] = calling_instance.readVInt()
        fields["Unk2"] = calling_instance.readVInt()
        LogicCommand.parseFields(fields)
        return fields

    def encode(self, fields):
    	pass

    def execute(self, calling_instance, fields, cryptoInit):
        fields["IsBrawlPassReward"] = False
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        playerData["Tokens"] -= 500
        playerData["GatchaItems"] = {'Boxes': []}
        box = {'Type': 0, 'Items': []}
        item = {'Amount': 50, 'DataRef': [0, 0],  'RewardID': 7}
        box['Type'] = 100
        box['Items'].append(item)
        item = {'Amount': 20, 'DataRef': [0, 0],  'RewardID': 24}
        box['Type'] = 100
        box['Items'].append(item)
        item = {'Amount': 5, 'DataRef': [0, 0],  'RewardID': 22}
        box['Type'] = 100
        box['Items'].append(item)
        playerData["Coins"] += 50
        playerData["PowerPoints"] += 20
        playerData["RecruitTokens"] += 5
        playerData["GatchaItems"]['Boxes'].append(box)
        db_instance.updatePlayerData(playerData, calling_instance)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        Messaging.sendMessage(24111, fields, cryptoInit)
            


    def getCommandType(self):
        return 535


