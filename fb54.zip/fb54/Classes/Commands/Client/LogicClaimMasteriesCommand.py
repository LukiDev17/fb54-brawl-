from Classes.Commands.LogicCommand import LogicCommand
from Classes.Messaging import Messaging
from Database.DatabaseHandler import DatabaseHandler
import json
from Classes.Readers.CSVReaders.Masteries import Masteries

class LogicClaimMasteriesCommand(LogicCommand):
    def __init__(self, commandData):
        super().__init__(commandData)

    def encode(self, fields):
        return self.messagePayload

    def decode(self, calling_instance):
        fields = {}
        fields["tick1"] = calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        calling_instance.readVInt()
        fields["Brawler"] = calling_instance.readDataReference()
        fields["MasteryIndex"] = calling_instance.readVInt()
        return fields

    def execute(self, calling_instance, fields, cryptoInit):
        db_instance = DatabaseHandler()
        playerData = json.loads(db_instance.getPlayerEntry(calling_instance.player.ID)[2])
        BrawlerID = fields["Brawler"][1]
        fields["IsBrawlPassReward"] = False
        playerData["GatchaItems"] = {'Boxes': []}
        VanityReader = Masteries.getMasteryVanityReward(BrawlerID)
        GivenItem = int(VanityReader["EmoteID"])
        if fields["MasteryIndex"] == 2:
        	ItemAmount = 750
        	ItemName = "Coins"
        	ItemID = 7
        	ItemSkin = 0
        	ItemReference = 0
        	playerData[ItemName] += ItemAmount
        elif fields["MasteryIndex"] == 3:
        	ItemAmount = 100
        	ItemName = "PowerPoints"
        	ItemID = 24
        	ItemSkin = 0
        	ItemReference = 0
        	playerData[ItemName] += ItemAmount
        elif fields["MasteryIndex"] == 4:
        	ItemAmount = 75
        	ItemName = "RecruitTokens"
        	ItemID = 22
        	ItemSkin = 0
        	ItemReference = 0
        	playerData[ItemName] += ItemAmount
        elif fields["MasteryIndex"] == 5:
        	ItemAmount = 200
        	ItemName = "PowerPoints"
        	ItemID = 24
        	ItemSkin = 0
        	ItemReference = 0
        	playerData[ItemName] += ItemAmount
        elif fields["MasteryIndex"] == 6:
        	ItemAmount = 1250
        	ItemName = "Coins"
        	ItemID = 7
        	ItemSkin = 0
        	ItemReference = 0
        	playerData[ItemName] += ItemAmount
        elif fields["MasteryIndex"] == 7:
        	ItemAmount = 150
        	ItemName = "RecruitTokens"
        	ItemID = 22
        	ItemSkin = 0
        	ItemReference = 0
        	playerData[ItemName] += ItemAmount     
        elif fields["MasteryIndex"] == 8:
        	ItemAmount = 1
        	ItemSkin = int(VanityReader["EmoteID"])
        	ItemName = "OwnedPins"
        	ItemID = 11
        	ItemReference = 52
        	playerData[ItemName].append(ItemSkin)
        elif fields["MasteryIndex"] == 9:
        	ItemAmount = 1
        	ItemSkin = int(VanityReader["ThumbnailID"])
        	ItemName = "OwnedThumbnails"
        	ItemID = 11
        	ItemReference = 28
        	playerData[ItemName].append(ItemSkin)
        elif fields["MasteryIndex"] == 10:
        	ItemAmount = 1
        	ItemSkin = int(VanityReader["TitleID"])
        	ItemName = "OwnedTitles"
        	ItemReference = 76
        	ItemID = 11
        	playerData[ItemName].append(ItemSkin)
        else:
        	pass
        for i, v in playerData["OwnedBrawlers"].items():
            if i == str(BrawlerID):
            	v['MasteryTier'] += 1
        
        box = {'Type': 100, 'Items': [{'Amount': ItemAmount, 'DataRef': [ItemReference, ItemSkin], 'RewardID': ItemID}]}
        playerData["GatchaItems"]['Boxes'].append(box)
        fields["Socket"] = calling_instance.client
        fields["Command"] = {"ID": 203}
        fields["PlayerID"] = calling_instance.player.ID
        db_instance.updatePlayerData(playerData, calling_instance)
        Messaging.sendMessage(24111, fields, cryptoInit)
        
        
        
        
        


    def getCommandType(self):
        return 569