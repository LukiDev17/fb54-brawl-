from Classes.ByteStreamHelper import ByteStreamHelper
from Classes.Packets.PiranhaMessage import PiranhaMessage
from Classes.Logic.LogicStarrDropData import starrDropOpening
from JSON.JSONHandler import JSONHandler
from Static.StaticData import StaticData
 

import random

from Database.DatabaseHandler import DatabaseHandler
class OwnHomeDataMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields, player):
        ownedBrawlersCount = len(player.OwnedBrawlers)
        ownedPinsCount = len(player.OwnedPins)
        ownedThumbnailCount = len(player.OwnedThumbnails)

        self.writeVInt(1488)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(player.Trophies)
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(player.HighestTrophies) 
        self.writeVInt(400)
        self.writeVInt(player.Experience)
        self.writeDataReference(28, player.Thumbnail)
        self.writeDataReference(43, player.Namecolor)

        self.writeVInt(843)
        for x in range(843):
            self.writeVInt(x)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)
        
        self.writeVInt(len(player.OwnedSkins))

        for skinID in player.OwnedSkins:
            self.writeDataReference(29, skinID)

        self.writeVInt(0)

        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(player.HighestTrophies)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(115)
        self.writeVInt(335442)
        self.writeVInt(1001442)
        self.writeVInt(400) # idk, какойт таймер а какой хз

        self.writeVInt(120)
        self.writeVInt(200)
        self.writeVInt(0) #drop

        self.writeBoolean(True)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0) # WTF IS THAT?        

        ShopData = JSONHandler.ShopData
        #ShopData = StaticData.ShopData

        self.writeVInt(len(ShopData["Offers"])) # count 3






        '''
        self.writeVInt(2) # RewardCount

        self.writeVInt(3)  # ItemType
        self.writeVInt(1) # Amount
        self.writeDataReference(16, 66)  # CsvID
        self.writeVInt(1) # SkinID
        
        self.writeVInt(1)  # ItemType
        self.writeVInt(2500) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(0) # SkinID
        
        
        self.writeVInt(6) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(1488) # Cost
        self.writeVInt(999999) # Time
        self.writeVInt(0)
        self.writeVInt(0)
      
        self.writeBoolean(False) # C
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(179) # Old price
        self.writeString(":3") # Text
        self.writeVInt(1)
        
        self.writeBoolean(False) #If True offer open on menu
               
        self.writeString("offer_bgr_hub") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString("ллл")
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(69, 9)
        self.writeDataReference(70, 0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(16)
        self.writeVInt(77)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(2)
        self.writeVInt(0) #доступно через (время)
        self.writeBoolean(False) #подарки 
        self.writeVInt(0) #Day Gift
        self.writeVInt(0) #Mode(0- Default, 1 - Gift)
        self.writeVInt(0) #Purchased(Gift offer)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeBoolean(False)

        self.writeVInt(1) # RewardCount
        self.writeVInt(4)
        self.writeVInt(1)
        self.writeDataReference(0)
        self.writeVInt(626)
        
        
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(0) # Cost
        self.writeVInt(99999) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Claim
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(179) # Old price
        self.writeString("БАБОЧКА ПАЙПЕР") # Text
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString("offer_bgr_hub") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString("ллл")
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(69, 9)
        self.writeDataReference(70, 1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(16)
        self.writeVInt(77)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(2)
        self.writeVInt(40) #доступно через (время)
        self.writeBoolean(False) #подарки 
        self.writeVInt(0) #Day Gift
        self.writeVInt(0) #Mode(0- Default, 1 - Gift)
        self.writeVInt(0) #Purchased(Gift offer)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeBoolean(False)

        self.writeVInt(1) # RewardCount
        self.writeVInt(16)  # ItemType
        self.writeVInt(1) # Amount
        self.writeDataReference(0)  # CsvID
        self.writeVInt(819) # SkinID
        
        
        self.writeVInt(0) # Currency(0-Gems, 1-Gold, 3-StarpoInts)
        self.writeVInt(0) # Cost
        self.writeVInt(99999) # Time
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # Daily Offer
        self.writeVInt(179) # Old price
        self.writeString("Еек ") # Text
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeString("offer_bgr_hub") # Background
        self.writeVInt(0)
        self.writeBoolean(False) # This purchase is already being processed
        self.writeVInt(0) # Type Benefit
        self.writeVInt(0) # Benefit
        self.writeString("ллл")
        self.writeBoolean(False) # One time offer
        self.writeBoolean(False) # Claimed
        self.writeDataReference(69, 9)
        self.writeDataReference(70, 1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(16)
        self.writeVInt(77)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(2)
        self.writeVInt(99999) #доступно через (время)
        self.writeBoolean(False) #подарки 
        self.writeVInt(0) #Day Gift
        self.writeVInt(0) #Mode(0- Default, 1 - Gift)
        self.writeVInt(0) #Purchased(Gift offer)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeBoolean(False)
        '''
        for i in ShopData["Offers"]:
            def checkAvailability():
            	results = []
            	result = False
            	for reward in i["Rewards"]:
            		if reward["ItemType"] == 3 or reward["ItemType"] == 30:
            			if str(reward["BrawlerID"][1]) in list(player.OwnedBrawlers.keys()):
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 19:
            			if reward["Extra"] in player.OwnedPins or i["IsForPortalEvent"] == True and str(i["NeedsBrawler"]) not in player.OwnedBrawlers:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 25:
            			if reward["Extra"] in player.OwnedThumbnails:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            		if reward["ItemType"] == 4:
            			if reward["Extra"] in player.OwnedSkins or i["IsForPortalEvent"] == True and str(i["NeedsBrawler"]) not in player.OwnedBrawlers:
            				if len(i["Rewards"]) > 1:
            					results.append(True)
            				else:
            					result = True
            	if i["Rewards"].index(reward) == len(i["Rewards"]) -1:
            		if True in results:
            			result = True
            	return result
            self.writeVInt(len(i["Rewards"]))
            for reward in i["Rewards"]:
                self.writeVInt(reward["ItemType"]) # ItemType
                self.writeVInt(reward["Amount"])
                if reward["BrawlerID"][0] != 0:
                    self.writeDataReference(reward["BrawlerID"][0], reward["BrawlerID"][1]) # CsvID
                else:
                    self.writeDataReference(0)
                self.writeVInt(reward["Extra"])
            self.writeVInt(i["Currency"])
            self.writeVInt(i["Cost"]) # new price
            self.writeVInt(i["Time"]) # timer until gone
            self.writeVInt(2)
            self.writeVInt(0)
            if ShopData["Offers"].index(i) in player.PurchasedOffers or checkAvailability() == True:
            	self.writeBoolean(True) # Claim
            else:
            	self.writeBoolean(i['Claim']) # Claim
            self.writeVInt(ShopData["Offers"].index(i))
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeVInt(i["OldPrice"]) # old price
            if i["Text"] == "None":
            	self.writeString()
            else:
            	self.writeString(i["Text"])
            self.writeVInt(0)
            self.writeBoolean(False)
            if i["Background"] == "None":
            	self.writeString()
            else:
            	self.writeString(i["Background"])
            self.writeVInt(-1)
            self.writeBoolean(i["Processed"])
            self.writeVInt(i["TypeBenefit"])
            self.writeVInt(i["Benefit"])
            self.writeString("")
            self.writeBoolean(i["OneTimeOffer"])
            self.writeBoolean(False)
            self.writeDataReference(i["ShopPanelLayout"][0], i["ShopPanelLayout"][1])
            self.writeDataReference(i["ShopStyleSet"][0], i["ShopStyleSet"][1]) #panel layout
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeVInt(-1)
            self.writeVInt(0)
            self.writeBoolean(False)
            self.writeBoolean(False)
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeBoolean(False)
            #self.writeVInt(0
           
            
            self.writeVInt(0)#i["ChainOfferTime"]) # timestamp 
            
            self.writeBoolean(False)#i["ChainOfferGifts"]) # Podarki?
            self.writeVInt(0)#i["ChainOfferGiftsDay"]) # Gift day
            self.writeVInt(0)#i["ChainOfferType"]) # 0 def, 1 gifts
            self.writeVInt(0) # purchased(gift)
            


            self.writeBoolean(False)


        self.writeVInt(player.Tokens)
        self.writeVInt(1428)

        self.writeVInt(0)

        self.writeVInt(1)
        self.writeVInt(30)

        player.GemsGained = 0

        self.writeByte(1) # count brawlers selected
        self.writeDataReference(16, 78) # selected brawler
        self.writeString(player.Region) # location
        self.writeString(player.ContentCreator) # supported creator

        self.writeVInt(21)
        self.writeDataReference(2, 1)  # Unknown
        self.writeDataReference(3, 0)  # Tokens Gained
        self.writeDataReference(4, 0)  # Trophies Gained
        player.TrophiesGained = 0
        self.writeDataReference(6, 0)  # Demo Account
        self.writeDataReference(7, 0)  # Invites Blocked
        self.writeDataReference(8, 0)  # Star Points Gained
        self.writeDataReference(9, 1)  # Show Star Points
        self.writeDataReference(10, 0)  # Power Play Trophies Gained
        self.writeDataReference(12, 1)  # Unknown
        self.writeDataReference(14, 0)  # Coins Gained
        self.writeDataReference(15, 3)  # AgeScreen | 3 = underage (disable social media) | 1 = age popup
        self.writeDataReference(16, 1)
        self.writeDataReference(17, 0)  # Team Chat Muted
        self.writeDataReference(18, 1)  # Esport Button
        self.writeDataReference(19, 0)  # Champion Ship Lives Buy Popup
        self.writeDataReference(20, 0)  # Gems Gained
        self.writeDataReference(21, 0)  # Looking For Team State
        self.writeDataReference(22, 1)
        self.writeDataReference(23, 0)  # Club Trophies Gained
        self.writeDataReference(24, 1)  # Have already watched club league stupid animation
        self.writeDataReference(37, 1488) # ScId

        self.writeVInt(0)

        # BrawlPassSeasonData::encode
        self.writeVInt(1)
        for season in range(1):
            self.writeVInt(24)
            self.writeVInt(0)
            self.writeBoolean(True) # BrawlPass Default Buy            
            self.writeVInt(0)
            self.writeBoolean(False)

            self.writeBoolean(True)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)

            self.writeBoolean(True)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)

            self.writeBoolean(True) # True - Enabled Brawl Pass +, False - Disabled
            self.writeBoolean(True)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
            self.writeInt(0)
        # BrawlPassSeasonData::encode

        self.writeVInt(0)

        self.writeBoolean(True)
        self.writeBoolean(True)
        self.writeVInt(1) 
        
        self.writeVInt(111) 
        self.writeVInt(222) 
        self.writeVInt(1) 
        self.writeVInt(10) 
        self.writeVInt(1488) 
        self.writeVInt(-1)
        self.writeVInt(1)
        self.writeVInt(35) 
        self.writeVInt(-1) # Refresh
        self.writeVInt(-1) #EventSlot idk what this
        self.writeVInt(2) #Reward Type
        self.writeVInt(4)
        self.writeVInt(2)
        self.writeVInt(1488) #Reward Count
        self.writeVInt(3)  #idk
        self.writeVInt(1)  #idk
        self.writeVInt(1) #idk
        self.writeVInt(1) #idk
        self.writeVInt(3) 
        self.writeVInt(2) 
        self.writeVInt(2) 
        self.writeVInt(1)
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeVInt(0) # Current LVL
        self.writeVInt(0) # Max LVL
        self.writeVInt(1488) 
        self.writeVInt(1)#Brawl Pass Need(1- Need)
        self.writeVInt(0)


        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(0) 

        self.writeBoolean(True) # Vanity items
        self.writeVInt(len(player.OwnedThumbnails)+len(player.OwnedPins))
        for ThumbnailID in player.OwnedThumbnails:
            self.writeDataReference(28, ThumbnailID)
            self.writeVInt(0)
        for PinID in player.OwnedPins:
            self.writeDataReference(52, PinID)
            self.writeVInt(0)

        self.writeBoolean(True) # 
        self.writeVInt(20) # 
        self.writeVInt(10000) # мяу 
        self.writeVInt(19) # вдвллчлв
        self.writeVInt(19) # вддвдч хз
        self.writeVInt(0) # Unk
        self.writeVInt(1) # 0
        self.writeVInt(2) # Unk
        self.writeVInt(0) 
        self.writeVInt(0) 
        self.writeBoolean(True)
        self.writeVInt(1)
        self.writeVInt(1) 
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeVInt(1)        

        self.writeInt(0)
        self.writeVInt(0)
        
        self.writeDataReference(16, 0)
        
        self.writeBoolean(False)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0) 

        self.writeVInt(2023189)


        self.writeVInt(35) # event slot id
        self.writeVInt(1)
        self.writeVInt(2)
        self.writeVInt(3)
        self.writeVInt(4)
        self.writeVInt(5)
        self.writeVInt(6)
        self.writeVInt(7)
        self.writeVInt(8)
        self.writeVInt(9)
        self.writeVInt(10)
        self.writeVInt(11)
        self.writeVInt(12)
        self.writeVInt(13) 
        self.writeVInt(14)
        self.writeVInt(15)
        self.writeVInt(16)
        self.writeVInt(17)
        self.writeVInt(18) 
        self.writeVInt(19)
        self.writeVInt(20)
        self.writeVInt(21) 
        self.writeVInt(22)
        self.writeVInt(23)
        self.writeVInt(24)
        self.writeVInt(25)
        self.writeVInt(26)
        self.writeVInt(27)
        self.writeVInt(28)
        self.writeVInt(29)
        self.writeVInt(30)
        self.writeVInt(31)
        self.writeVInt(32)
        self.writeVInt(33)
        self.writeVInt(34)
        self.writeVInt(35)

        self.writeVInt(12) #Event Count       
        
        #Default Maps Start
        self.writeVInt(4)
        self.writeVInt(1) #BrawlBall
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 454) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        self.writeVInt(4)
        self.writeVInt(2) #ShowDown
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 430) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        self.writeVInt(4)
        self.writeVInt(3) #Daily Event
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 10) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        self.writeVInt(4)
        self.writeVInt(4) #Team Event
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 441) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        self.writeVInt(4)
        self.writeVInt(5) #DUO SHOWDOWN
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 431) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        #Deafult Maps End
        
        #Candidate Day Maps Start
        self.writeVInt(4)
        self.writeVInt(12)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 10) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        #Candidate Day Maps End
        
        #Winner Day Map Start
        self.writeVInt(4)
        self.writeVInt(13)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 454) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # array
        
        self.writeBoolean(True) # MapMaker map structure array
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("t.me/catstudioss") # map name
        self.writeVInt(5) #game mode variation
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
       
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("ПЕНИСКИ ОТЦА")
        self.writeVInt(0)
        
        self.writeBoolean(False) #String
        
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        #Winner Day Map End
        
        #Club League Start
        self.writeVInt(4)
        self.writeVInt(16)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, 10) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        
        self.writeVInt(4)
        self.writeVInt(17)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, -1) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        #Club League End
        
        #Piggy Clubs Start
        self.writeVInt(4)
        self.writeVInt(35)
        self.writeVInt(-1)
        self.writeVInt(72292)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, -1) # map id
        self.writeVInt(2)
        
        self.writeVInt(1)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(False) # Power League array entr        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(3)  #count maps 1
        self.writeDataReference(15, 662) #map 1
        self.writeDataReference(15, 667) #map 2
        self.writeDataReference(15, 668) #map 3
        self.writeVInt(3)  #count maps 2
        self.writeDataReference(15, 662) #map 1
        self.writeDataReference(15, 667) #map 2
        self.writeDataReference(15, 668) #map 3
        self.writeVInt(3) #modifier count
        self.writeVInt(23) #modifier 1
        self.writeVInt(21) #modifier 2
        self.writeVInt(20) #modifier 3
        self.writeVInt(2)
        self.writeBoolean(True) 
        self.writeVInt(2)
        self.writeVInt(7)
        
        self.writeVInt(3) #Count
        
        self.writeVInt(3) # starr drop rewards for 1 mesto
        self.writeVInt(2) # starr drop rewards for second mesto
        self.writeVInt(1) # starr drop rewards for 3 mesto
        #Piggy Clubs End
        
        #Hyper Event Start
        self.writeVInt(4)
        self.writeVInt(34)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, -1) # map id
        self.writeVInt(-1)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)        
        self.writeLong(0, 1) 
        self.writeDataReference(0, 0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        
        self.writeVInt(0)
        
        self.writeBoolean(False) #sub_6BA960
        """
        self.writeVInt(0)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True) #String
        self.writeString("")
        self.writeVInt(0)
        self.writeBoolean(False) #String
        
        self.writeBoolean(False) #String
        
        
        self.writeVInt(-1)
        self.writeBoolean(True) #sub_689964
        self.writeString("")
        self.writeString("")
        self.writeBoolean(False) #sub_56EBF8
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        """
        
        self.writeVInt(-1)
        
        
        
        self.writeVInt(1) 
        
        self.writeVInt(1)
        self.writeDataReference(0, 0)
        
        self.writeVInt(1) #
        self.writeVInt(0)
        
        self.writeVInt(0) 
        self.writeBoolean(False) #Piggy
        """
        self.writeVInt(0) #?
        self.writeVInt(0) #?
        self.writeVInt(1) #count
        self.writeVInt(0) #starr drops count
        """
        #Hyper Event End

        #Range Battle Start
        self.writeVInt(4)
        self.writeVInt(14)
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(72292)
        self.writeVInt(10) 
        self.writeDataReference(15, -1) # map id
        self.writeVInt(3)
        self.writeVInt(2)
        self.writeString("")
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeVInt(-1)     
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False) # MapMaker map structure array
        self.writeVInt(0)
        self.writeBoolean(True) # Power League array entr
        self.writeVInt(24)
        self.writeString("Dog Brawl")
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(1)
        self.writeVInt(0)
        self.writeVInt(0)
        
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(-1)
        self.writeBoolean(False)
        self.writeBoolean(False)
        self.writeVInt(3) # count maps 1
        self.writeDataReference(15, 10) #map 1
        self.writeDataReference(15, 680) #map 2
        self.writeDataReference(15, 5) #map 3
        self.writeVInt(3) # count maps 2
        self.writeDataReference(15, 10) #map1
        self.writeDataReference(15, 680) #map 2
        self.writeDataReference(15, 5) #map 3
        self.writeVInt(3) #modifier count
        self.writeVInt(23) #modifier 1
        self.writeVInt(21) #modifier 2
        self.writeVInt(20) #modifier 3
        self.writeVInt(5) #idk?
        
        self.writeBoolean(False) 
       
        self.writeVInt(0) # Comming Events
       
        ByteStreamHelper.encodeIntList(self, [20, 35, 75, 140, 290, 480, 800, 1250, 1875, 2800])
        ByteStreamHelper.encodeIntList(self, [30, 80, 170, 360]) # Shop Coins Price
        ByteStreamHelper.encodeIntList(self, [300, 880, 2040, 4680]) # Shop Coins Amount

        self.writeVInt(1) # Locked Brawler
        for i in range(1):
            self.writeDataReference(29, 29)
            self.writeInt(3600) # Time
            self.writeInt(3500)
            self.writeInt(3400)
            self.writeBoolean(True)

        self.writeVInt(1) # IntValueEntry
        self.writeDataReference(41000091, 1) # ThemeID        

        self.writeVInt(1) #Custom Event
        
        self.writeVInt(3)
        self.writeVInt(3)
        self.writeVInt(3)
        self.writeVInt(3)
       
        self.writeBoolean(False) # a1[37] + 4 * v13++
        
        
        
        self.writeVInt(1) #lol
        self.writeBoolean(True)
        self.writeString("шваль настя пво") #SUBTITLE
        self.writeVInt(0) #TID
        
        self.writeVInt(1) # mb count?
        self.writeDataReference(69, 9) #offer id
        #self.writeDataReference(69, 9) #offer id

        self.writeVInt(1) #idk
        
        self.writeString("offer_bgr_hub") #Background
        
        self.writeBoolean(True) #boolean
        self.writeString("алалыдядчжжебн")  #TITLE
        self.writeVInt(0) #TID
        

        
        self.writeVInt(1) #count?
        self.writeVInt(1)
        self.writeVInt(1)
        
        self.writeString("")

        self.writeDataReference(29, 819)
        
        self.writeVInt(0) #a1[43] + 4 * v15++
        """
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeString("idk lol")
        self.writeVInt(0)
        self.writeVInt(1)
        self.writeBoolean(True)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeDataReference(0,0)
        self.writeVInt(0)
        self.writeBoolean(True)
        self.writeVInt(1)
        self.writeVInt(1)
        self.writeDataReference(0,0)
        self.writeVInt(1)
        self.writeDataReference(0,0)
        self.writeString("idk2")
        self.writeVInt(0)
        """
        
        ByteStreamHelper.encodeIntList(self, [1, 2])        
        ByteStreamHelper.encodeIntList(self, [1, -64])        
        ByteStreamHelper.encodeIntList(self, [1, 4])
        ByteStreamHelper.encodeIntList(self, [0, 29, 79, 169, 349, 699])
        ByteStreamHelper.encodeIntList(self, [0, 160, 450, 500, 1250, 2500])

        self.writeLong(player.ID[0], player.ID[1]) # Player ID
        
        self.writeVInt(0) # notif
        
        '''
        self.writeVInt(82)
        self.writeInt(228) #Notification ID
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("")
        self.writeVInt(1)
        self.writeVInt(1)
        
        
        self.writeVInt(83)
        self.writeInt(7) #Notification ID
        self.writeBoolean(False)
        self.writeInt(0)
        self.writeString("")
        self.writeVInt(1)
        '''

 
        self.writeVInt(1)
        self.writeBoolean(False)
        self.writeVInt(0) # gatcha drop
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeBoolean(True)
        #self.writeVInt(0)
        
        LoginData = JSONHandler.LoginData
        
        self.writeVInt(0)
        self.writeVInt(len(LoginData["LoginItems"])) # amount of items in login calendar
        for x in LoginData["LoginItems"]:
        	self.writeVInt(x["Day"]) #day     	
        	self.writeVInt(len(x["Rewards"]))#count
        	for reward in x["Rewards"]:
        		self.writeVInt(reward["ItemType"])
        		self.writeVInt(reward["Amount"])
        		self.writeDataReference(16, reward["BrawlerID"][1])
        		self.writeVInt(reward["Extra"])
        		self.writeBoolean(False)
                
        
        self.writeVInt(1) # Road Count
             
        self.writeVInt(0) # Road
        self.writeVInt(1) # Reward Amount
        
        self.writeVInt(6) #day
        self.writeVInt(1) #amount
        
        self.writeVInt(45)
        self.writeVInt(2750)
        self.writeDataReference(16,0)
        self.writeVInt(0)
        self.writeBoolean(False)
                                               
        self.writeVInt(player.LoginRewardIndex)#если 1 то вылетает что ты не получишь награду
        self.writeVInt(9339)# настя сво
        self.writeVInt(9339)
        self.writeVInt(player.ClaimedLoginRewardIndex)
        self.writeVInt(0) 
        self.writeVInt(2)
        self.writeVInt(0)
        self.writeVInt(0)
        # new function v46
        self.writeVInt(0) # new function v46
        self.writeBoolean(True) 
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        
        if True:
            self.writeVInt(1)
        
            rare = [1, 2, 3, 6, 8, 10, 13, 24]
            super_rare = [7, 9, 18, 19, 22, 25, 27, 34, 61, 4]
            epic = [14, 15, 16, 20, 26, 29, 30, 36, 43, 45, 48, 50, 58, 69]
            mythic = [11, 17, 21, 35, 31, 32, 37, 42, 47, 64, 67, 71, 73]
            legendary = [5, 12, 23, 28, 40, 52, 63]
        
            x = player.RecruitBrawler
        
            self.writeDataReference(16, player.RecruitBrawler) 
            
            if x in rare:
                self.writeVInt(160)
            elif x in super_rare:
                self.writeVInt(430)
            elif x in epic:
                self.writeVInt(925)
            elif x in mythic:
               self.writeVInt(1900)
            elif x in legendary:
                self.writeVInt(3800)
            else:
                self.writeVInt(1)
            
            
            if x in rare:
                self.writeVInt(29)
            elif x in super_rare:
                self.writeVInt(79)
            elif x in epic:
                self.writeVInt(169)
            elif x in mythic:
                self.writeVInt(359)
            elif x in legendary:
                self.writeVInt(699)
            else:
                self.writeVInt(1)
            
            self.writeVInt(0)
            self.writeVInt(player.RecruitTokens) 
            self.writeVInt(0) 
            self.writeVInt(0)
        else:
        	self.writeVInt(0)
        
        
        self.writeVInt(len(player.Brawlers))
        for x in player.Brawlers:
            self.writeDataReference(16, x) 
                      
            
            if x in rare:
                self.writeVInt(160)
            elif x in super_rare:
                self.writeVInt(430)
            elif x in epic:
                self.writeVInt(925)
            elif x in mythic:
                self.writeVInt(1900)
            elif x in legendary:
                self.writeVInt(3800)
            else:
            	self.writeVInt(1)
            
            
            if x in rare:
                self.writeVInt(29)
            elif x in super_rare:
                self.writeVInt(79)
            elif x in epic:
                self.writeVInt(169)
            elif x in mythic:
                self.writeVInt(359)
            elif x in legendary:
                self.writeVInt(699)
            else:
            	self.writeVInt(1)
            
           
            self.writeVInt(0)
            self.writeVInt(0)
            self.writeVInt(player.Brawlers.index(x)) 
            self.writeVInt(0)
        
        self.writeVInt(0)
        
        self.writeVInt(0) 
        # Starr Road End
        
       
        
        self.writeVInt(len(player.OwnedBrawlers)) # new function v48
        for brawlerID,brawlerInfo in player.OwnedBrawlers.items():           
            self.writeVInt(brawlerInfo["MasteryPoints"])
            self.writeVInt(brawlerInfo["MasteryTier"])
            self.writeDataReference(16, brawlerID)
        

        self.writeVInt(0) # v48
        if player.BattleIcon1Visible == True:
        	self.writeDataReference(28, player.BattleIcon1)
        else:
        	self.writeDataReference(0)
        if player.BattleIcon2Visible == True:
        	self.writeDataReference(28, player.BattleIcon2)
        else:
        	self.writeDataReference(0)
        if player.BattleEmoteVisible == True:
        	self.writeDataReference(52, player.BattleEmote)
        else:
        	self.writeDataReference(0)
        if player.TitleVisible == True:
        	self.writeDataReference(76, player.Title)
        else:
        	self.writeDataReference(0)
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48
        self.writeBoolean(False)  # v48

        self.writeVInt(0) #Brawler's BattleCards
        '''
        self.writeVInt(5)
        for i in range(5):
            self.writeDataReference(80, i)
            self.writeVInt(-1)
            self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeInt(0)
        self.writeVInt(0) 
        self.writeVInt(0)
        self.writeVInt(86400*24)
        self.writeVInt(0)
        self.writeVInt(0)

        '''
        starrDropOpening.encode(self, player)
        self.writeBoolean(False)
        
        #starrDropOpening.encode(self, player)

        # end LogicClientHome
        
        self.writeInt(0) # new v54 (по либе тут не инт но оно работает и так)

        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeVLong(player.ID[0], player.ID[1])
        self.writeStringReference(player.Name)
        self.writeBoolean(player.Registered)
        self.writeInt(-1)

        self.writeVInt(17)
        unlocked_brawler = [i['CardID'] for x,i in player.OwnedBrawlers.items()]
        self.writeVInt(len(unlocked_brawler) + 2)
        for x in unlocked_brawler:
            self.writeDataReference(23, x)
            self.writeVInt(-1)
            self.writeVInt(1)

        self.writeDataReference(5, 8)
        self.writeVInt(-1)
        self.writeVInt(player.Coins)

        self.writeDataReference(5, 23)
        self.writeVInt(-1)
        self.writeVInt(1000)

        self.writeVInt(len(player.OwnedBrawlers)) # HeroScore
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["Trophies"])

        self.writeVInt(len(player.OwnedBrawlers)) # HeroHighScore
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["HighestTrophies"])

        self.writeVInt(0) # Array

        self.writeVInt(0) # HeroPower
        
        self.writeVInt(len(player.OwnedBrawlers)) # HeroLevel
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(i["PowerLevel"]-1)

        self.writeVInt(0) # hero star power gadget and hypercharge

        self.writeVInt(len(player.OwnedBrawlers)) # HeroSeenState
        for x,i in player.OwnedBrawlers.items():
            self.writeDataReference(16, x)
            self.writeVInt(-1)
            self.writeVInt(2)

        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array
        self.writeVInt(0) # Array

        self.writeVInt(player.Gems) # Diamonds
        self.writeVInt(player.Gems) # Free Diamonds
        self.writeVInt(10) # Player Level
        self.writeVInt(100)
        self.writeVInt(0) # CumulativePurchasedDiamonds or Avatar User Level Tier | 10000 < Level Tier = 3 | 1000 < Level Tier = 2 | 0 < Level Tier = 1
        self.writeVInt(100) # Battle Count
        self.writeVInt(10) # WinCount
        self.writeVInt(80) # LoseCount
        self.writeVInt(50) # WinLooseStreak
        self.writeVInt(20) # NpcWinCount
        self.writeVInt(0) 
        self.writeVInt(2) # TutorialState | shouldGoToFirstTutorialBattle = State == 0
        self.writeVInt(12)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeString()
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(1)

    def decode(self):
        fields = {}
        return fields

    def execute(message, calling_instance, fields):
        pass

    def getMessageType(self):
        return 24101

    def getMessageVersion(self):
        return self.messageVersion