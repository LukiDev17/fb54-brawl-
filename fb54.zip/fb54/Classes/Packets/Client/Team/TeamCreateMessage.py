from Classes.Messaging import Messaging

from Classes.Packets.PiranhaMessage import PiranhaMessage


class TeamCreateMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Unk1"] = self.readVInt()
        fields["Unk2"] = self.readVInt()
        fields["Type"] = self.readVInt()
        fields["Unk3"] = self.readVInt()
        print(fields["Type"], fields["Unk2"], fields["Unk1"]) #print
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        Messaging.sendMessage(24124, fields, cryptoInit, calling_instance.player)

    def getMessageType(self):
        return 14350

    def getMessageVersion(self):
        return self.messageVersion
