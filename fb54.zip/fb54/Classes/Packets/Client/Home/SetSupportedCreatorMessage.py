from Classes.Messaging import Messaging
from Classes.Packets.PiranhaMessage import PiranhaMessage
import Configuration
from Database.DatabaseHandler import DatabaseHandler
from Static.StaticData import StaticData
import json
from JSON.JSONHandler import JSONHandler


class SetSupportedCreatorMessage(PiranhaMessage):
    def __init__(self, messageData):
        super().__init__(messageData)
        self.messageVersion = 0

    def encode(self, fields):
        pass

    def decode(self):
        fields = {}
        fields["Message"] = self.readString()
        print(fields["Message"])
        return fields

    def execute(message, calling_instance, fields, cryptoInit):
        fields["Socket"] = calling_instance.client
        db_instance = DatabaseHandler()
        player_data = db_instance.getPlayer(calling_instance.player.ID)

        cdata = JSONHandler.CodesData
        
        # Проверьте, что cdata["Codes"] является списком

        for i in cdata["Codes"]:
            if fields["Message"] in i['Code']:
                player_data["ContentCreator"] = i["Code"]
                if i['Reward'] == "True":
                    player_data["Gems"] += i['Count']
                fields["Socket"] = calling_instance.client
                fields["Command"] = {"ID": 215}
                fields["SupportedCreator"] = fields["Message"]
                Messaging.sendMessage(24111, fields, cryptoInit)
                break  # выход из i
        else:
            fields["Code"] = player_data["ContentCreator"]
            Messaging.sendMessage(28686, fields, cryptoInit)

        db_instance.updatePlayerData(player_data, calling_instance)
        	
    def getMessageType(self):
        return 18686

    def getMessageVersion(self):
        return self.messageVersion