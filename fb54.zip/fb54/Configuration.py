# DisableNagle: reduce delay and improve performance between client and server BUT require more power #

settings = {
    "DisableNagle": True,
    "PrintEnabled": True,
    "UseContentUpdater": False,
    "Proxy": False,
    "DumpPacket": False,
    "Blacklist": [24109],
    "DumpMajor": 44,
    "ChallengeEnabled": True,
    "ChallengeLives": 4,
    "ChallengeLogicName": "thrower_challenge",
    "ChallengeVariation": 7,
    "ChallengeName": "Test",
    "ChallengeStages": 1,
    "ChallengeTotalWins": 3,
    "ChallengeMaps": [476, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "ChallengeMapsWins": [3, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    "ChallengeFinalReward": {"Type": 19, "Amount": 1, "Brawler": [0, 0], "Extra": 637},
    "ChallengeRewards": [{"Win": 1,"Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 2, "Type": 1, "Amount": 100, "Brawler": [0, 0], "Extra": 0}, {"Win": 3, "Type": 14, "Amount": 1, "Brawler": [0, 0], "Extra": 0}]
}