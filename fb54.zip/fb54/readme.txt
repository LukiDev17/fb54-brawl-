The basis is taken from starrdev, everything is agreed.

🤷 I'm tired of disassembling the shop, it doesn't work in some places ok?

Today I will tell you how to use this server, what is where and so on. Let's go!

Let's start with the shop.

Take a look at the JSON/Shop/Shop.json file. All the data about the promotions should be stored there. First, let's talk about the bottom lines.

Currency - the currency for which the promotion is purchased
Cost - the price of the promotion
Time - the time until the promotion disappears
Claim - if false, then the promotion works as usual, if true, then it is hidden
DailyOffer - does it work at all on new versions? It is essentially useless, but it used to work and was a gift of the day
OldPrice - old price of the promotion
Text - promotion title
Background - promotion background
Processed - text "This purchase is being processed."
TypeBenefit -
1. like benefit (quantity)%
2. more by (quantity)%
3. like promotion (quantity)%
Benefit - that same (quantity)
OneTimeOffer - one-time offer
ShopPanelLayout -
69, 0: skin + mini fighter below
69, 1: skin + fighter with 3D models
69, 2: championship icons
69, 3: championship pins
69, 4: group icons
69, 5: group icons
69, 8: aaa I don't know chain offers!
69, 9: fixed in ohd chain offers
ShopStyleSet - set to 70, 0 if you want to get a big promotion (only accepts a fighter + resource, pin.. it doesn't matter, the main thing is that it doesn't accept a skin)
IsForMoonEvent - useless
BoxType - useless
IsForPortalEvent - too lazy to rename, BUT! set true if you want a certain item not to be displayed until the player has a fighter (put the ID of the fighter you need in NeedsBrawler)
IsForHorizonEvent - useless
LoadOnStartup - in theory it should load the promotion when you enter the game, but it doesn't seem to work
StarrDrops - set true only if these are starr drops
NeedsBrawler - already explained
UpdateOffers - set true if you want this promotion to update the entire store

I think I explained the main part, now for Rewards.

ItemType - the item that should be displayed. I can explain the basics:
12 - Old Power Points (write "PowerPoints" in ItemName)
9 - Token Doubler (do not write anything in ItemName, I did not make it and it will not be given)
1 - Coins (write "Coins" in ItemName)
16 - Gems (write "Gems" in ItemName)

19 - Icon (write "OwnedPins" in ItemName and icon ID in Extra)
25 - Player Icon (write "OwnedThumbnails" in ItemName and icon ID in Extra)

3 - Brawler (in BrawlerID - [16, brawler ID], in BrawlerCard - brawler code ID (I will tell you later), brawler power (if you want) in BrawlerPower)

4 - Skin (only write the ID in Extra, again, if you do not want the skin displayed as "Yes" in NeedsBrawler enter the ID of the brawler that is associated with this skin and IsForPortalEvent => True)

38 - Credits (in ItemName - "RecruitTokens")
39 - Chroma Credits (in ItemName - "ChromaticCoins")
41 - New Power Points (in ItemName - "PowerPoints")
45 - Blings (in ItemName - "Bling")
49 - Starr Drops (nothing is needed in ItemName, StarrDrops => True)
Starr Drop Rarities (write everything in Extra):
0 - Rare
1 - Super Rare
2 - Epic
3 - Mythical
4 - Legendary
5 - I think hypercharged, I haven't tested

Amount - amount of resource

How to search for brawlers and their special IDs in BrawlerCard?

See those 2 files in the main folder - Characters.json and Cards.json? We need them now. Let's say you want to take Spike:
Look for the line "Spike" in Characters. Above it there will be the number "Brawler" - 5. You need to remember it.

Then go to Cards.json, look for the item with Brawler => 5 and look at UnlockCard for this item. This is our special ID for BrawlerCard - 20.

How to look for IDs of pins, skins?

Pure selection and knowledge of English. I will attach Emotes, Skins, look for an approximate icon / skin that you need by ID ("Skin" / "EmoteID"), look there for what skin / icon in TID.

Basically everything ;)

What about the rest?

In DropsData you will find a lot of interesting things. This is the data about Starr Drops. There you can change the rewards:
MinFallback (minimum amount of item)
MaxFallback (maximum amount of item)
DeliveryID - everything is interesting here.

11 - icons, pins (28 in DataRef for icons, 52 in DataRef for pins)
9 - skins (29 in DataRef for them, in ItemID - "OwnedSkins")
7 - coins
8 - gems
25 - blings
22 - credits
23 - chromacredits
24 - power points

ItemID - I already talked about data types, as in the case of ItemName in Shop.json,

I also just talked about DataRef.

How to change player data when entering the game?

The Classes/Instances/Classes/Player.py file stores player data. Let's run through the important ones:

Thumbnail - set icon
Namecolor - name color
Coins - coins
Gems - gems

Additions from stealdev

Now let's talk about creator codes

Codes are in JSON/Codes.json:
Code - code that will be correct when entered (example: LRBS)
Reward - whether gems will be given for entering (True/False)
Count - number of gems for entering